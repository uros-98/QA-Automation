package com.practicetestautomation.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ExceptionsPage extends BasePage{
    private By addBtnLocator = By.id("add_btn");
    private By row2InputField = By.xpath("//div[@id='row2']/input");
    private By row1InputField = By.xpath("//div[@id='row1']/input");
    private By row2SaveBtnLocator = By.xpath("//div[@id='row2']/button[@name='Save']");
    private By row1SaveBtnLocator = By.xpath("//div[@id='row1']/button[@name='Save']");
    private By getSuccessMessage = By.id("confirmation");
    private By EditBtnLocator = By.id("edit_btn");
    private By instructionElementLocator = By.id("confirmation");

    public ExceptionsPage(WebDriver driver) {
        super(driver);
    }

    public void visit() {
        super.visit("https://practicetestautomation.com/practice-test-exceptions/");
    }

    public void pushAddButton() {
        driver.findElement(addBtnLocator).click();
    }

    public boolean isRow2DisplayedAfterWait() {
        return waitForIsDisplayed(row2InputField);
    }

    public void enterFoodInInputField(String name) {
        driver.findElement(row2InputField).sendKeys(name);
    }

    public void saveRow1() {
        driver.findElement(row1SaveBtnLocator).click();
    }

    public void saveRow2() {
        driver.findElement(row2SaveBtnLocator).click();
    }

    public String getSuccessMessage() {
        return waitForElement(getSuccessMessage).getText();
    }

    public void pushEditBtn() {
        driver.findElement(EditBtnLocator).click();
    }

    public void enterFoodInRow1(String name) {
        driver.findElement(row1InputField).clear();
        driver.findElement(row1InputField).sendKeys(name);
    }

    public boolean isElementElementHiddenAfterWait() {
        return waitForIsHidden(instructionElementLocator);
    }
}
